import type { NavigationState } from '@react-navigation/routers';
import { type GetStateListener } from './NavigationBuilderContext.js';
type Options = {
    getState: () => NavigationState;
    getStateListeners: Record<string, GetStateListener | undefined>;
};
export declare function useOnGetState({ getState, getStateListeners }: Options): void;
export {};
//# sourceMappingURL=useOnGetState.d.ts.map