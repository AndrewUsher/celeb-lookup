import type { ParamListBase } from '@react-navigation/routers';
import * as React from 'react';
import type { NavigationProp } from './types.js';
export declare const OptionsGetterContext: React.Context<((key: string, getter: () => object | undefined | null) => void) | undefined>;
type Options = {
    key?: string;
    navigation?: NavigationProp<ParamListBase>;
    options?: object | undefined;
};
export declare function useOptionsGetters({ key, options, navigation }: Options): {
    addOptionsGetter: (key: string, getter: () => object | undefined | null) => () => void;
    getCurrentOptions: () => object | null | undefined;
};
export {};
//# sourceMappingURL=useOptionsGetters.d.ts.map