export default interface FrameCallbackRegistryUI {
    frameCallbackRegistry: Map<number, () => void>;
    frameCallbackActive: Set<number>;
    isFrameCallbackRunning: boolean;
    runCallbacks: () => void;
    registerFrameCallback: (callback: () => void, callbackId: number) => void;
    unregisterFrameCallback: (frameCallbackId: number) => void;
    manageStateFrameCallback: (frameCallbackId: number, state: boolean) => void;
}
export declare const prepareUIRegistry: () => void;
