export default class FrameCallbackRegistryJS {
    private nextCallbackId;
    constructor();
    registerFrameCallback(callback: () => void): number;
    unregisterFrameCallback(frameCallbackId: number): void;
    manageStateFrameCallback(frameCallbackId: number, state: boolean): void;
}
