export declare type FrameCallback = {
    setActive: (isActive: boolean) => void;
    isActive: boolean;
    callbackId: number;
};
export declare function useFrameCallback(callback: () => void, autostart?: boolean): FrameCallback;
