type QueryValue = string | null | (string | null)[];
export declare function parse(query: string): Record<string, QueryValue>;
export declare function stringify(params: Record<string, string | string[] | null>): string;
export {};
//# sourceMappingURL=queryString.d.ts.map