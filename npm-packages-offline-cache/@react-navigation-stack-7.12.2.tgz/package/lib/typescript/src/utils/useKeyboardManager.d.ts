import * as React from 'react';
import { type HostInstance } from 'react-native';
export declare function useKeyboardManager({ active, enabled, focused, contentRef, }: {
    active: boolean;
    enabled: boolean;
    focused: boolean;
    contentRef: React.RefObject<HostInstance | null>;
}): {
    onPageChangeStart: () => void;
    onPageChangeConfirm: ({ gesture, active, closing, }: {
        gesture: boolean;
        active: boolean;
        closing: boolean;
    }) => void;
    onPageChangeCancel: () => void;
};
//# sourceMappingURL=useKeyboardManager.d.ts.map