import { type HostInstance } from 'react-native';
export declare function viewIsDescendantOf(view: HostInstance, ancestor: HostInstance, callback: (isDescendant: boolean) => void): void;
//# sourceMappingURL=viewIsDescendantOf.d.ts.map