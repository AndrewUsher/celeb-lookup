import type { LocaleDirection } from '@react-navigation/native';
import type { PanGestureHandlerProperties } from 'react-native-gesture-handler';
import type { GestureDirection, Layout } from '../types.js';
export declare const gestureActivationCriteria: ({ direction, gestureDirection, gestureResponseDistance, layout, }: {
    direction: LocaleDirection;
    gestureDirection: GestureDirection;
    gestureResponseDistance?: number;
    layout: Layout;
}) => PanGestureHandlerProperties;
//# sourceMappingURL=gestureActivationCriteria.d.ts.map