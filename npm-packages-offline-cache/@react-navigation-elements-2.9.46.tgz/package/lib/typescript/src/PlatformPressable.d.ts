import * as React from 'react';
import { Animated, type GestureResponderEvent, Pressable, type PressableProps, type StyleProp, type ViewStyle } from 'react-native';
type HoverEffectProps = {
    color?: string;
    hoverOpacity?: number;
    activeOpacity?: number;
};
export type Props = Omit<PressableProps, 'style' | 'onPress'> & {
    href?: string;
    pressColor?: string;
    pressOpacity?: number;
    hoverEffect?: HoverEffectProps;
    style?: Animated.WithAnimatedValue<StyleProp<ViewStyle>>;
    onPress?: (e: React.MouseEvent<HTMLAnchorElement, MouseEvent> | GestureResponderEvent) => void;
    children: React.ReactNode;
};
type PressableRef = React.ComponentRef<ReturnType<typeof Animated.createAnimatedComponent<typeof Pressable>>>;
export declare const PlatformPressable: React.ForwardRefExoticComponent<Props & React.RefAttributes<PressableRef>>;
export {};
//# sourceMappingURL=PlatformPressable.d.ts.map