import * as React from 'react';
import { PlatformPressable } from '../PlatformPressable.js';
import type { HeaderButtonProps } from '../types.js';
export declare const HeaderButton: React.ForwardRefExoticComponent<HeaderButtonProps & React.RefAttributes<React.ComponentRef<typeof PlatformPressable>>>;
//# sourceMappingURL=HeaderButton.d.ts.map