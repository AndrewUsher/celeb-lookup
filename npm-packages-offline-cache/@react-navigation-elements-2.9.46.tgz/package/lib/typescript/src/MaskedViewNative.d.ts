/**
 * The native MaskedView that we explicitly re-export for supported platforms: Android, iOS.
 */
import * as React from 'react';
import { type ViewProps } from 'react-native';
type Props = ViewProps & {
    maskElement: React.ReactElement;
    androidRenderingMode?: 'software' | 'hardware';
    children: React.ReactElement;
};
export declare function MaskedView({ children, ...rest }: Props): React.JSX.Element;
export {};
//# sourceMappingURL=MaskedViewNative.d.ts.map