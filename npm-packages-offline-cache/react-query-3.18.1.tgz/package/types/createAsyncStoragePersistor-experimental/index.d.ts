interface AsyncStorage {
    getItem: (key: string) => Promise<string>;
    setItem: (key: string, value: string) => Promise<unknown>;
    removeItem: (key: string) => Promise<unknown>;
}
interface CreateAsyncStoragePersistorOptions {
    /** The storage client used for setting an retrieving items from cache */
    storage: AsyncStorage;
    /** The key to use when storing the cache */
    key?: string;
    /** To avoid spamming,
     * pass a time in ms to throttle saving the cache to disk */
    throttleTime?: number;
}
export declare const asyncStoragePersistor: ({ storage, key, throttleTime, }: CreateAsyncStoragePersistorOptions) => {
    persistClient: (...args: any) => Promise<void>;
    restoreClient: () => Promise<any>;
    removeClient: () => Promise<unknown>;
};
export {};
