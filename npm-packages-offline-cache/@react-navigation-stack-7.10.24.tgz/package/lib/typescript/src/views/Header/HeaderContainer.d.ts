import { type Route } from '@react-navigation/native';
import * as React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import type { Layout, Scene, StackHeaderMode } from '../../types.js';
export type Props = {
    mode: StackHeaderMode;
    layout: Layout;
    scenes: (Scene | undefined)[];
    getPreviousScene: (props: {
        route: Route<string>;
    }) => Scene | undefined;
    getFocusedRoute: () => Route<string>;
    contentHeight: number | undefined;
    onContentHeightChange?: (props: {
        route: Route<string>;
        height: number;
    }) => void;
    style?: StyleProp<ViewStyle>;
};
export declare function HeaderContainer({ mode, scenes, layout, getPreviousScene, getFocusedRoute, contentHeight, onContentHeightChange, style, }: Props): React.JSX.Element;
//# sourceMappingURL=HeaderContainer.d.ts.map