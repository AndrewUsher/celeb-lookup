import * as React from 'react';
import type { StackHeaderProps } from '../../types.js';
export declare const Header: React.MemoExoticComponent<({ back, layout, progress, options, route, navigation, styleInterpolator, }: StackHeaderProps) => React.JSX.Element>;
//# sourceMappingURL=Header.d.ts.map