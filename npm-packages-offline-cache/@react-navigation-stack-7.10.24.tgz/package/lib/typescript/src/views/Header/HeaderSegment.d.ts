import * as React from 'react';
import type { Layout, SceneProgress, StackHeaderOptions, StackHeaderStyleInterpolator } from '../../types.js';
type Props = Omit<StackHeaderOptions, 'headerStatusBarHeight'> & {
    headerStatusBarHeight: number;
    layout: Layout;
    title: string;
    modal: boolean;
    onGoBack?: () => void;
    backHref?: string;
    progress: SceneProgress;
    styleInterpolator: StackHeaderStyleInterpolator;
};
export declare function HeaderSegment(props: Props): React.JSX.Element;
export {};
//# sourceMappingURL=HeaderSegment.d.ts.map