import type { GestureDirection } from '../types.js';
export declare function getInvertedMultiplier(gestureDirection: GestureDirection, isRTL: boolean): 1 | -1;
//# sourceMappingURL=getInvertedMultiplier.d.ts.map