import type { LocaleDirection } from '@react-navigation/native';
import type { GestureDirection, Layout } from '../types.js';
export declare const gestureActivationCriteria: ({ direction, gestureDirection, gestureResponseDistance, layout, }: {
    direction: LocaleDirection;
    gestureDirection: GestureDirection;
    gestureResponseDistance?: number;
    layout: Layout;
}) => {
    maxDeltaX: number;
    minOffsetY: number;
    hitSlop: {
        bottom: number;
        top?: undefined;
        right?: undefined;
        left?: undefined;
    };
    enableTrackpadTwoFingerGesture: boolean;
    minOffsetX?: undefined;
    maxDeltaY?: undefined;
} | {
    maxDeltaX: number;
    minOffsetY: number;
    hitSlop: {
        bottom?: undefined;
        top: number;
        right?: undefined;
        left?: undefined;
    };
    enableTrackpadTwoFingerGesture: boolean;
    minOffsetX?: undefined;
    maxDeltaY?: undefined;
} | {
    maxDeltaX?: undefined;
    minOffsetY?: undefined;
    minOffsetX: number;
    maxDeltaY: number;
    hitSlop: {
        bottom?: undefined;
        top?: undefined;
        right: number;
        left?: undefined;
    };
    enableTrackpadTwoFingerGesture: boolean;
} | {
    maxDeltaX?: undefined;
    minOffsetY?: undefined;
    minOffsetX: number;
    maxDeltaY: number;
    hitSlop: {
        bottom?: undefined;
        top?: undefined;
        right?: undefined;
        left: number;
    };
    enableTrackpadTwoFingerGesture: boolean;
};
//# sourceMappingURL=gestureActivationCriteria.d.ts.map