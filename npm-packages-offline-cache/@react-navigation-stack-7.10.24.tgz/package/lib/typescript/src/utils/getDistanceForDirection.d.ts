import type { GestureDirection, Layout } from '../types.js';
export declare function getDistanceForDirection(layout: Layout, gestureDirection: GestureDirection, isRTL: boolean): number;
//# sourceMappingURL=getDistanceForDirection.d.ts.map