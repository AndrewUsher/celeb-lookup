import * as React from 'react';
import type { StackCardInterpolationProps } from '../types.js';
export declare const CardAnimationContext: React.Context<StackCardInterpolationProps | undefined>;
//# sourceMappingURL=CardAnimationContext.d.ts.map