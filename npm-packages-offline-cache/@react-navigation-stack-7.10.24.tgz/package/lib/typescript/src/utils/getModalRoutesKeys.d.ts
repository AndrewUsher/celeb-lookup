import type { Route } from '@react-navigation/native';
import type { StackDescriptorMap } from '../types.js';
export declare const getModalRouteKeys: (routes: Route<string>[], descriptors: StackDescriptorMap) => string[];
//# sourceMappingURL=getModalRoutesKeys.d.ts.map