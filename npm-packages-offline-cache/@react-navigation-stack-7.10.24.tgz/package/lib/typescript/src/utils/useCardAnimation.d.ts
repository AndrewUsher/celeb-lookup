export declare function useCardAnimation(): import("../index.js").StackCardInterpolationProps;
//# sourceMappingURL=useCardAnimation.d.ts.map