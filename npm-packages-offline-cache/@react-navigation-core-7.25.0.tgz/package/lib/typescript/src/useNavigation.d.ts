import type { GenericNavigation } from './types.js';
/**
 * Hook to access the navigation prop of the parent screen anywhere.
 *
 * @returns Navigation prop of the parent screen.
 */
export declare function useNavigation<T = GenericNavigation<ReactNavigation.RootParamList>>(): T;
//# sourceMappingURL=useNavigation.d.ts.map