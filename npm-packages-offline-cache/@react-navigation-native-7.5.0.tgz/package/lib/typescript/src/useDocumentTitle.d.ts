import type { NavigationContainerRef, ParamListBase } from '@react-navigation/core';
import * as React from 'react';
import type { DocumentTitleOptions } from './types.js';
/**
 * Set the document title for the active screen
 */
export declare function useDocumentTitle(ref: React.RefObject<NavigationContainerRef<ParamListBase> | null>, { enabled, formatter, }?: DocumentTitleOptions): void;
//# sourceMappingURL=useDocumentTitle.d.ts.map