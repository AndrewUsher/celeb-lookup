import * as React from 'react';
type ScrollOptions = {
    x?: number;
    y?: number;
    animated?: boolean;
};
type ScrollableView = {
    scrollToTop(): void;
} | {
    scrollTo(options: ScrollOptions): void;
} | {
    scrollToOffset(options: {
        offset: number;
        animated?: boolean;
    }): void;
} | {
    scrollResponderScrollTo(options: ScrollOptions): void;
};
type ScrollableWrapper = {
    getScrollResponder(): React.ReactNode | ScrollableView;
} | {
    getNode(): ScrollableView;
} | ScrollableView | null;
export declare function useScrollToTop(ref: React.RefObject<ScrollableWrapper>): void;
export {};
//# sourceMappingURL=useScrollToTop.d.ts.map