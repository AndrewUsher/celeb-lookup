import * as React from 'react';
import type { HeaderButtonProps } from '../types.js';
export declare const HeaderButton: React.ForwardRefExoticComponent<HeaderButtonProps & React.RefAttributes<import("react-native").Animated.LegacyRef<import("react-native").View> | import("react-native").View>>;
//# sourceMappingURL=HeaderButton.d.ts.map